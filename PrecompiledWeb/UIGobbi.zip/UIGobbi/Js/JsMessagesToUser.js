﻿function PopupRemisionCreadaOk()
{
       setTimeout("alert('La remisión se ha creado con éxito');", 1000);
}